#ifndef UNIT_LED_TEST_H
#define UNIT_LED_TEST_H

#include <unity.h>
#include "gpio.h"
#include "stdbool.h" //Nodig om bool te kunnen gebruiken
#include "stm32f3xx_hal.h"
#include "main.h"

void run_led_test();

#endif